
var sdkbox = sdkbox || {};
sdkbox.bb = sdkbox.bb || {};
if (!sdkbox.bb.Msg) {

var counter = 0;

function Msg(plugin, func) {
    counter++;
    this.plugin = plugin;
    this.msgId = counter;
    this.func = func;
    this.tag = "";
    this.values = [];
}

Msg.prototype.setPlugin = function (plugin) {
    this.plugin = plugin
}

Msg.prototype.setFunc = function (f) {
    this.func = f
}

Msg.prototype.setPlugin = function(s) {
    this.plugin = s
}

Msg.prototype.setFunc = function(s) {
    this.func = s
}

Msg.prototype.setTag = function(s) {
    this.tag = s
}

Msg.prototype.pushValue = function(v) {
    this.values.push(v)
}

Msg.prototype.clearValues = function() {
    this.values = []
}

sdkbox.bb.Msg = Msg;

}
