#include <sstream>
#include "BridgeJSHelper.h"
#include "Bridge/Bridge.hpp"

#define MAKE_V8_HAPPY \
se::ScriptEngine::getInstance()->clearException(); \
se::AutoHandleScope hs;

namespace sdkbox { namespace bb {

static void splitStr(const std::string& str, const std::string& token, std::vector<std::string>& parts) {
    size_t nend = 0;
    size_t nbegin = 0;
    size_t tokenSize = token.size();
    while(nend != std::string::npos) {
        nend = str.find(token, nbegin);
        if(nend == std::string::npos)
            parts.push_back(str.substr(nbegin, str.length()-nbegin));
        else
            parts.push_back(str.substr(nbegin, nend-nbegin));
        nbegin = nend + tokenSize;
    }
}

static se::Value getOrCreateValue(se::Object* obj, const std::string& path) {
    std::vector<std::string> vect;
    splitStr(path, ".", vect);

    se::Object* root = obj;
    se::Value ret;
    for (auto n : vect) {
        if (nullptr == root) {
            CCLOG("ERROR, object is null");
            break;
        }
        if (!root->getProperty(n.c_str(), &ret)) {
            ret.setObject(se::Object::createPlainObject());
            root->setProperty(n.c_str(), ret);
        }
        root = ret.toObject();
    }
    return ret;
}

static se::Value getValueByPath(se::Object* obj, const std::string& path) {
    std::vector<std::string> vect;
    splitStr(path, ".", vect);

    se::Object* root = obj;
    se::Value ret;
    for (auto n : vect) {
        if (nullptr == root) {
            CCLOG("ERROR, object is null");
            break;
        }
        root->getProperty(n.c_str(), &ret);
        root = ret.toObject();
    }
    return ret;
}

static se::Value uniVal2Val(const sdkbox::bb::UniValue& uVal) {
    se::Value val;

    switch (uVal.getType()) {
        case sdkbox::bb::UniValueType::UniValueTypeInt: {
            val.setInt32(uVal.intValue());
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeFloat: {
            val.setFloat(uVal.floatValue());
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeBoolean: {
            val.setBoolean(uVal.booleanValue());
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeString: {
            val.setString(uVal.stringValue());
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeByteArray: {
            int len = 0;
            const unsigned char* pVal = uVal.byteArrayValue(&len);
            auto objArr = se::Object::createArrayBufferObject((void*)pVal, len);
            val.setObject(objArr);
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeMap: {
            auto obj = se::Object::createPlainObject();
            
            for (auto it : uVal.mapValue()) {
                obj->setProperty(it.first.c_str(), uniVal2Val(it.second));
            }

            val.setObject(obj);
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeList: {
            auto listVal = uVal.listValue();
            auto obj = se::Object::createArrayObject(listVal.size());
            
            int i = 0;
            for (auto it : listVal) {
                obj->setArrayElement(i, uniVal2Val(it));
                i++;
            }

            val.setObject(obj);
            break;
        }
        default:
            break;
    }
    
    return val;
}

static se::Value msg2JSVal(const sdkbox::bb::Msg& msg) {
    se::Value val;
    se::Object* obj = se::Object::createPlainObject();
    
    auto objVals = se::Object::createArrayObject(msg.getValueListLength());
    for (int i = 0; i < msg.getValueListLength(); i++) {
        objVals->setArrayElement(i, uniVal2Val(msg.getValue(i)));
    }

    obj->setProperty("id", se::Value(msg.getId()));
    obj->setProperty("plugin", se::Value(msg.getPlugin()));
    obj->setProperty("func", se::Value(msg.getFunc()));
    obj->setProperty("tag", se::Value(msg.getTag()));
    obj->setProperty("values", se::Value(objVals));

    val.setObject(obj);

    return val;
}

static sdkbox::bb::UniValue val2UniVal(const se::Value& val) {
    sdkbox::bb::UniValue uVal;

    if (val.isBoolean()) {
        uVal.booleanValue(val.toBoolean());
    } else if (val.isNumber()) {
        uVal.intValue(val.toInt32());
    } else if (val.isString()) {
        uVal.stringValue(val.toString());
    } else if (val.isObject()) {
        auto obj = val.toObject();
        if (obj->isArrayBuffer()) {
            uint8_t* data = nullptr;
            size_t len = 0;
            obj->getArrayBufferData(&data, &len);
            uVal.byteArrayValue((unsigned char*)data, (int)len);
        } else if (obj->isArray()) {
            sdkbox::bb::UniValueList uValList;
            se::Value valItem;
            uint32_t len;
            obj->getArrayLength(&len);
            for (int i = 0; i < len; i++) {
                obj->getArrayElement(i, &valItem);
                uValList.push_back(val2UniVal(valItem));
            }
            uVal.listValue(uValList);
        } else {
            sdkbox::bb::UniValueMap uValMap;
            
            std::vector<std::string> keys;
            obj->getAllKeys(&keys);
            for (auto key : keys) {
                se::Value mapVal;
                if (obj->getProperty(key.c_str(), &mapVal)) {
                    uValMap[key] = val2UniVal(mapVal);
                }
            }
            uVal.mapValue(uValMap);
        }
    }
    
    return uVal;
}

static sdkbox::bb::Msg jsVal2msg(const se::Value& val) {
    sdkbox::bb::Msg msg(0);
    
    auto obj = val.toObject();
    if (nullptr == obj) {
        return msg;
    }
    
    se::Value v;
    if (obj->getProperty("id", &v)) { msg.setId(v.toInt32()); }
    if (obj->getProperty("plugin", &v)) { msg.setPlugin(v.toString()); }
    if (obj->getProperty("func", &v)) { msg.setFunc(v.toString()); }
    if (obj->getProperty("tag", &v)) { msg.setTag(v.toString()); }
    if (obj->getProperty("values", &v)) {
        auto objVals = v.toObject();
        if (nullptr != objVals) {
            uint32_t len = 0;
            objVals->getArrayLength(&len);
            for (int i = 0; i < len; i++) {
                se::Value valParam;
                objVals->getArrayElement(i, &valParam);
                if (valParam.isBoolean()) {
                    msg.pushValue(valParam.toBoolean());
                } else if (valParam.isNumber()) {
                    msg.pushValue(valParam.toInt32());
                } else if (valParam.isString()) {
                    msg.pushValue(valParam.toString());
                } else if (valParam.isObject()) {
                    auto objParam = valParam.toObject();
                    if (objParam->isArrayBuffer()) {
                        uint8_t* data = nullptr;
                        size_t len = 0;
                        objParam->getArrayBufferData(&data, &len);
                        msg.pushValue((unsigned char*)data, (int)len);
                    } else if (objParam->isArray()) {
                        se::Value valParam;
                        objParam->getArrayElement(i, &valParam);
                    }
                }
            }
        }
    }

    return msg;
}

static void invokeJSFun(const se::Value& valFun, const se::ValueArray& params) {
    auto objFun = valFun.toObject();
    if (nullptr == objFun || !objFun->isFunction()) {
        CCLOG("param function value is null or not a function type");
        return;
    }

    se::ScriptEngine::getInstance()->clearException();
    se::AutoHandleScope hs;

    bool ok = objFun->call(params, objFun);
    if (!ok) {
        CCLOG("Call JS function failed");
    }
    se::ScriptEngine::getInstance()->clearException();

    /*
    for (int i = 0; i < params.size(); i++) {
        const se::Value& param = params.at(i);
        if (param.isObject()) {
            param.toObject()->unroot();
        }
    }
    */
}

}}

static std::vector<se::Value> _bbOnRecvs;

static bool js_SDKBox_BB_Bridge_onRecv(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;

    if (1 != argc) {
        SE_REPORT_ERROR("Bridge.onRecv wrong number of arguments: %d, was expecting %d", (int)argc, 1);
        return false;
    }

    se::Value valFun = args[0];
    _bbOnRecvs.push_back(valFun);
    sdkbox::bb::Bridge::onRecv([valFun](const sdkbox::bb::Msg& msg) {
        MAKE_V8_HAPPY

        se::ValueArray params;
        params.push_back(sdkbox::bb::msg2JSVal(msg));
        sdkbox::bb::invokeJSFun(valFun, params);
    });

    return true;
}
SE_BIND_FUNC(js_SDKBox_BB_Bridge_onRecv)

static bool js_SDKBox_BB_Bridge_onInit(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;

    if (0 != argc && 1 != argc) {
        SE_REPORT_ERROR("Bridge.onInit wrong number of arguments: %d, was expecting 0 or 1", (int)argc);
        return false;
    }

    std::map<std::string, std::string> argMap;
    if (1 == argc) {
        seval_to_std_map_string_string(args[0], &argMap);
    }
    sdkbox::bb::Bridge::init(argMap);

    return true;
}
SE_BIND_FUNC(js_SDKBox_BB_Bridge_onInit)

static bool js_SDKBox_BB_Bridge_onAddPlugin(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;

    if (2 != argc) {
        SE_REPORT_ERROR("Bridge.onAddPlugin wrong number of arguments: %d, was expecting %d", (int)argc, 2);
        return false;
    }

    std::string s1 = "";
    std::string s2 = "";
    ok &= seval_to_std_string(args[0], &s1);
    ok &= seval_to_std_string(args[1], &s2);
    SE_PRECONDITION2(ok, false, "Bridge.onAddPlugin : need two string params");
    sdkbox::bb::Bridge::addPlugin(s1, s2);

    return true;
}
SE_BIND_FUNC(js_SDKBox_BB_Bridge_onAddPlugin)

static bool js_SDKBox_BB_Bridge_onSend(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;

    if (1 != argc && 2 != argc) {
        SE_REPORT_ERROR("Bridge.onAddPlugin wrong number of arguments: %d, was expecting %d", (int)argc, 2);
        return false;
    }
    
    auto msg = sdkbox::bb::jsVal2msg(args[0]);
    if (2 == argc) {
        auto valFun = args[1];
        sdkbox::bb::Bridge::send(msg, [valFun](const sdkbox::bb::Msg& m) {
            MAKE_V8_HAPPY

            se::ValueArray params;
            params.push_back(sdkbox::bb::msg2JSVal(m));
            sdkbox::bb::invokeJSFun(valFun, params);
        });
    } else {
        sdkbox::bb::Bridge::send(msg);
    }

    return true;
}
SE_BIND_FUNC(js_SDKBox_BB_Bridge_onSend)

bool register_Bridge_module(se::Object* obj) {
    auto valBridge = sdkbox::bb::getOrCreateValue(obj, "sdkbox.bb.Bridge");
    auto objBridge = valBridge.toObject();
    if (nullptr == objBridge) {
        CCLOG("Bridge Object is null");
        return false;
    }

    objBridge->defineFunction("onRecv", _SE(js_SDKBox_BB_Bridge_onRecv));
    objBridge->defineFunction("init", _SE(js_SDKBox_BB_Bridge_onInit));
    objBridge->defineFunction("addPlugin", _SE(js_SDKBox_BB_Bridge_onAddPlugin));
    objBridge->defineFunction("send", _SE(js_SDKBox_BB_Bridge_onSend));

    se::ScriptEngine::getInstance()->clearException();
    
    return true;
}

