#pragma once

#include "jsapi.h"
#include "jsfriendapi.h"

#if MOZJS_MAJOR_VERSION >= 31
void register_Bridge_module(JSContext* cx, JS::HandleObject global);
#else
void register_Bridge_module(JSContext* cx, JSObject* global);
#endif

