#include <sstream>
#include "scripting/js-bindings/manual/cocos2d_specifics.hpp"
#include "BridgeJSHelper.h"
#include "Bridge/Bridge.hpp"

#define BB_STR_TO_JSVAL(cx, s) (0 == (s).size() ? JS::StringValue(JS_NewStringCopyZ((cx), "")) : JS::StringValue(JS_NewStringCopyZ((cx), (s).c_str())));
#define BB_CSTR_TO_JSVAL(cx, s) (0 == (s) ? JS::StringValue(JS_NewStringCopyZ((cx), "")) : JS::StringValue(JS_NewStringCopyZ((cx), (s))));


static std::vector<JS::PersistentRootedObject*> _bbOnRecvs;

extern JSObject* jsb_sdkbox_PluginAdColony_prototype;

static JSContext* s_cx = nullptr;


/*
 * Utils Functions
 */
namespace sdkbox { namespace bb {
#if defined(MOZJS_MAJOR_VERSION) and MOZJS_MAJOR_VERSION >= 26

    void getJsObjOrCreat(JSContext* cx, JS::HandleObject jsObj, const char* name, JS::MutableHandleObject retObj) {
        JS::RootedObject parent(cx);
        JS::RootedObject tempObj(cx);
        bool first = true;

        std::stringstream ss(name);
        std::string sub;
        const char* subChar;
        while(getline(ss, sub, '.')) {
            if(sub.empty())continue;

            subChar = sub.c_str();
            if (first) {
                get_or_create_js_obj(cx, jsObj, subChar, &tempObj);
                first = false;
            } else {
                parent = tempObj;
                get_or_create_js_obj(cx, parent, subChar, &tempObj);
            }
        }

        retObj.set(tempObj.get());
    }

#else

jsval getJsObjOrCreat(JSContext* cx, JSObject* jsObj, const char* name, JSObject** retObj) {
    JSObject* parent = NULL;
    JSObject* tempObj = jsObj;
    jsval tempVal;

    std::stringstream ss(name);
    std::string sub;
    const char* subChar;

    while(getline(ss, sub, '.')) {
        if(sub.empty())continue;

        subChar = sub.c_str();
        parent = tempObj;
        JS_GetProperty(cx, parent, subChar, &tempVal);
        if (tempVal == JSVAL_VOID) {
            tempObj = JS_NewObject(cx, NULL, NULL, NULL);
            tempVal = OBJECT_TO_JSVAL(tempObj);
            JS_SetProperty(cx, parent, subChar, &tempVal);
        } else {
            JS_ValueToObject(cx, tempVal, &tempObj);
        }
    }

    *retObj = tempObj;
    return tempVal;
}

#endif

void invokeJSCallback(JSContext* cx, JS::HandleObject handler, JS::HandleValue msg) {
    if (nullptr == cx) {
        return;
    }

    JS::RootedObject rHandlerObj(cx, handler);
    JS::RootedValue rHandlerVal(cx);
    JSAutoCompartment ac(cx, rHandlerObj);

    rHandlerVal = OBJECT_TO_JSVAL(rHandlerObj.get());
#if defined(MOZJS_MAJOR_VERSION)
#if MOZJS_MAJOR_VERSION >= 33
    JS::RootedValue retval(cx);
#else
    jsval retval;
#endif
#elif defined(JS_VERSION)
    jsval retval;
#endif

    JS::Value dataVal[2];
    int datalen = 0;

    dataVal[0] = msg;
    datalen = 1;

#if MOZJS_MAJOR_VERSION >= 31
    JS_CallFunctionValue(cx, rHandlerObj, rHandlerVal,
                         JS::HandleValueArray::fromMarkedLocation(1, dataVal), &retval);
    // JS_CallFunctionName(cx, obj, func_name, JS::HandleValueArray::fromMarkedLocation(datalen, dataVal), &retval);
#else
    JS_CallFunctionValue(cx, obj, handler, datalen, dataVal, &retval);
#endif

}

void uniValue2JSVal(JSContext *cx, const sdkbox::bb::UniValue& val, JS::MutableHandleValue retVal) {
#if MOZJS_MAJOR_VERSION >= 31
    JS::RootedValue rVal(cx);
#else
    jsval jVal;
    JSObject* rVal = JS_NewObject(cx, null, null, null);
#endif

    switch (val.getType()) {
        case sdkbox::bb::UniValueType::UniValueTypeInt: {
            rVal = JS::NumberValue(val.intValue());
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeFloat: {
            rVal = JS::NumberValue(val.floatValue());
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeBoolean: {
            rVal = JS::BooleanValue(val.booleanValue());
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeString: {
            rVal = BB_STR_TO_JSVAL(cx, val.stringValue());
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeByteArray: {
            int len = 0;
            const unsigned char* pVal = val.byteArrayValue(&len);
            JS::RootedObject array(cx, JS_NewUint8Array(cx, len));
            if (nullptr == array)
                break;

            uint8_t* bufdata = (uint8_t*)JS_GetArrayBufferViewData(array);
            memcpy(bufdata, pVal, len*sizeof(uint8_t));
            rVal = OBJECT_TO_JSVAL(array);
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeMap: {
            JS::RootedObject jsObj(cx, JS_NewObject(cx, NULL, JS::NullPtr(), JS::NullPtr()));

            for (auto it : val.mapValue()) {
                JS::RootedValue val(cx);

                uniValue2JSVal(cx, it.second, &val);
                JS_SetProperty(cx, jsObj, it.first.c_str(), val);
            }

            rVal = OBJECT_TO_JSVAL(jsObj);
            break;
        }
        case sdkbox::bb::UniValueType::UniValueTypeList: {
            JS::RootedObject jsArr(cx, JS_NewArrayObject(cx, 0));

            int i = 0;
            for (auto it : val.listValue()) {
                JS::RootedValue arrElement(cx);

                uniValue2JSVal(cx, it, &arrElement);
                if(!JS_SetElement(cx, jsArr, i, arrElement)) {
                    break;
                }
                
                ++i;
            }

            rVal = OBJECT_TO_JSVAL(jsArr);
            break;
        }
        default:
            break;
    }

    retVal.set(rVal);
}

void msg2JSVal(JSContext* cx, const sdkbox::bb::Msg& m, JS::MutableHandleValue retVal) {
#if defined(MOZJS_MAJOR_VERSION)
#if MOZJS_MAJOR_VERSION >= 33
#if MOZJS_MAJOR_VERSION >= 52
    JS::RootedObject jsobj(cx, JS_NewObject(cx, NULL));
#else
    JS::RootedObject jsobj(cx, JS_NewObject(cx, NULL, JS::NullPtr(), JS::NullPtr()));
#endif
    JS::RootedValue id(cx);
    JS::RootedValue plugin(cx);
    JS::RootedValue func(cx);
    JS::RootedValue tag(cx);
    JS::RootedObject values(cx, JS_NewArrayObject(cx, m.getValueListLength()));

    id = JS::NumberValue(m.getId());
    plugin = BB_STR_TO_JSVAL(cx, m.getPlugin());
    func = BB_STR_TO_JSVAL(cx, m.getFunc());
    tag = BB_STR_TO_JSVAL(cx, m.getTag());
    for (int i = 0; i < m.getValueListLength(); i++) {
        JS::RootedValue uVal(cx);
        const sdkbox::bb::UniValue& val = m.getValue(i);
        uniValue2JSVal(cx, val, &uVal);

        if (!JS_SetElement(cx, values, i, uVal)) {
            break;
        }
    }

    JS_SetProperty(cx, jsobj, "id", id);
    JS_SetProperty(cx, jsobj, "plugin", plugin);
    JS_SetProperty(cx, jsobj, "func", func);
    JS_SetProperty(cx, jsobj, "tag", tag);
    
    JS::RootedValue vals(cx);
    vals = OBJECT_TO_JSVAL(values);
    JS_SetProperty(cx, jsobj, "values", vals);

#else
    JSObject* jsobj = JS_NewObject(cx, NULL, NULL, NULL);
    JS::RootedValue id(cx);
    JS::RootedValue plugin(cx);
    JS::RootedValue func(cx);
    JS::RootedValue tag(cx);
    JS::RootedObject values(cx, JS_NewArrayObject(cx, m.getValueListLength()));

    id = JS::NumberValue(m.getId());
    plugin = BB_STR_TO_JSVAL(cx, m.getPlugin());
    func = BB_STR_TO_JSVAL(cx, m.getFunc());
    tag = BB_STR_TO_JSVAL(cx, m.getTag());
    for (int i = 0; i < m.getValueListLength(); i++) {
        JS::RootedObject uniVal(cx);
        uniValue2JSVal(cx, m.getValue(i), &uniVal);

        if (!JS_SetElement(cx, values, i, uniVal)) {
            break;
        }
    }

    JS_SetProperty(cx, jsobj, "id", id);
    JS_SetProperty(cx, jsobj, "plugin", plugin);
    JS_SetProperty(cx, jsobj, "func", func);
    JS_SetProperty(cx, jsobj, "tag", tag);
    JS_SetProperty(cx, jsobj, "values", values);

#endif
#elif defined(JS_VERSION)
    JSObject* jsobj = JS_NewObject(cx, NULL, NULL, NULL);
    jsval id;
    jsval plugin;
    jsval func;
    jsval tag;

    id = JS::NumberValue(m.getId());
    plugin = BB_STR_TO_JSVAL(cx, m.getPlugin());
    func = BB_STR_TO_JSVAL(cx, m.getFunc());
    tag = BB_STR_TO_JSVAL(cx, m.getTag());

    JS_SetProperty(cx, jsobj, "id", &id);
    JS_SetProperty(cx, jsobj, "plugin", &plugin);
    JS_SetProperty(cx, jsobj, "func", &func);
    JS_SetProperty(cx, jsobj, "tag", &tag);
#endif

    retVal.set(OBJECT_TO_JSVAL(jsobj));
}

sdkbox::bb::UniValue jsval2UniValue(JSContext* cx, JS::HandleValue jsVal) {
    if (jsVal.isNullOrUndefined()) {
        return sdkbox::bb::UniValue();
    }
    
    JS::RootedValue rVal(cx, jsVal);
    
    if (rVal.isString()) {
        JSStringWrapper valueWapper(rVal.toString(), cx);
        return sdkbox::bb::UniValue::stringValue(valueWapper.get());
    } else if (rVal.isDouble()) {
        double d = rVal.toDouble();
        return sdkbox::bb::UniValue::floatValue(d);
    } else if (rVal.isBoolean()) {
        bool b = rVal.toBoolean();
        return sdkbox::bb::UniValue::booleanValue(b);
    } else if (rVal.isNumber()) {
        int i = rVal.toInt32();
        return sdkbox::bb::UniValue::intValue(i);
    } else if (rVal.isObject()) {
        JS::RootedObject rObj(cx, rVal.toObjectOrNull());
        if (JS_IsArrayObject(cx, rObj)) {
            uint32_t len = 0;
            sdkbox::bb::UniValueList uValList;

            JS_GetArrayLength(cx, rObj, &len);
            for (uint32_t i=0; i < len; i++) {
                JS::RootedValue rEleVal(cx);
                if (JS_GetElement(cx, rObj, i, &rEleVal)) {
                    uValList.push_back(jsval2UniValue(cx, rEleVal));
                }
            }
            return sdkbox::bb::UniValue::listValue(uValList);
        } else {
            JS::RootedObject it(cx, JS_NewPropertyIterator(cx, rObj));
            sdkbox::bb::UniValueMap uValMap;

            while (true) {
                JS::RootedId idp(cx);
                JS::RootedValue key(cx);
                if (!JS_NextProperty(cx, it, idp.address()) || !JS_IdToValue(cx, idp, &key)) {
                    break;
                }

                if (key.isNullOrUndefined()) {
                    break;
                }

                if (!key.isString()) {
                    continue;
                }

                JSStringWrapper keyWrapper(key.toString(), cx);
                JS::RootedValue value(cx);
                JS_GetPropertyById(cx, rObj, idp, &value);

                uValMap[keyWrapper.get()] = jsval2UniValue(cx, value);
            }
            return sdkbox::bb::UniValue::mapValue(uValMap);
        }
    } else {
        JS_ReportError(cx, "not supported type in msg object");
        return sdkbox::bb::UniValue();
    }
}

void jsval2Msg(JSContext* cx, JS::HandleValue jsVal, sdkbox::bb::Msg* m) {
    if (jsVal.isNullOrUndefined()) {
        return;
    }

    JS::RootedObject rVal(cx, jsVal.toObjectOrNull());
    if (!rVal) {
        CCLOG("%s", "jsval2Msg: the jsval is not an object.");
        return ;
    }

    JS::RootedValue value(cx);
    JS_GetProperty(cx, rVal, "msgId", &value);
    if (value.isNumber()) {
        m->setId(value.toInt32());
    }
    
    JS_GetProperty(cx, rVal, "plugin", &value);
    if (value.isString()) {
        JSStringWrapper valueWapper(value.toString(), cx);
        m->setPlugin(valueWapper.get());
    }
    
    JS_GetProperty(cx, rVal, "func", &value);
    if (value.isString()) {
        JSStringWrapper valueWapper(value.toString(), cx);
        m->setFunc(valueWapper.get());
    }
    
    JS_GetProperty(cx, rVal, "tag", &value);
    if (value.isString()) {
        JSStringWrapper valueWapper(value.toString(), cx);
        m->setTag(valueWapper.get());
    }
    
    JS_GetProperty(cx, rVal, "values", &value);
    if (value.isObject()) {
        JS::RootedObject rVals(cx, value.toObjectOrNull());
        uint32_t len = 0;
        JS_GetArrayLength(cx, rVals, &len);
        for (uint32_t i=0; i < len; i++) {
            JS::RootedValue rEleVal(cx);
            if (JS_GetElement(cx, rVals, i, &rEleVal)) {
                m->pushValue(jsval2UniValue(cx, rEleVal));
            }
        }
    }
}

}}




#if defined(MOZJS_MAJOR_VERSION)
bool js_BB_Bridge_onRecv(JSContext *cx, uint32_t argc, JS::Value *vp)
#elif defined(JS_VERSION)
JSBool js_BB_Bridge_onRecv(JSContext *cx, uint32_t argc, jsval *vp)
#endif
{
    if (1 != argc) {
        JS_ReportError(cx, "Bridge.onRecv wrong number of arguments");
        return false;
    }
    JS::CallArgs args = JS::CallArgsFromVp(argc, vp);
    auto arg = args.get(0);
    if (!arg.isObject()) {
        return false;
    }

    auto f = new JS::PersistentRootedObject(cx, arg.toObjectOrNull());
    _bbOnRecvs.push_back(f);
    sdkbox::bb::Bridge::onRecv([cx, f](const sdkbox::bb::Msg& msg) {
        JS::RootedValue rMsg(cx);
        JS::RootedObject rObj(cx, f->get());

        sdkbox::bb::msg2JSVal(cx, msg, &rMsg);

        sdkbox::bb::invokeJSCallback(cx, rObj, rMsg);
    });

    return true;
}

#if defined(MOZJS_MAJOR_VERSION)
bool js_BB_Bridge_init(JSContext *cx, uint32_t argc, JS::Value *vp)
#elif defined(JS_VERSION)
JSBool js_BB_Bridge_init(JSContext *cx, uint32_t argc, jsval *vp)
#endif
{
    if (0 != argc && 1 != argc) {
        JS_ReportError(cx, "Bridge.onRecv expect 0 or 1 argument");
        return false;
    }
    JS::CallArgs args = JS::CallArgsFromVp(argc, vp);
    auto arg = args.get(0);
    std::map<std::string, std::string> argMap;
    jsval_to_std_map_string_string(cx, arg, &argMap);
    sdkbox::bb::Bridge::init(argMap);

    return true;
}

#if defined(MOZJS_MAJOR_VERSION)
bool js_BB_Bridge_addPlugin(JSContext *cx, uint32_t argc, JS::Value *vp)
#elif defined(JS_VERSION)
JSBool js_BB_Bridge_addPlugin(JSContext *cx, uint32_t argc, jsval *vp)
#endif
{
    if (2 != argc) {
        JS_ReportError(cx, "Bridge.addPlugin expect 2 arguments");
        return false;
    }
    JS::CallArgs args = JS::CallArgsFromVp(argc, vp);

    auto arg1 = args.get(0);
    JSStringWrapper s1w(arg1.toString(), cx);
    std::string s1 = s1w.get();

    auto arg2 = args.get(1);
    JSStringWrapper s2w(arg2.toString(), cx);
    std::string s2 = s2w.get();

    sdkbox::bb::Bridge::addPlugin(s1, s2);

    return true;
}

#if defined(MOZJS_MAJOR_VERSION)
bool js_BB_Bridge_send(JSContext *cx, uint32_t argc, JS::Value *vp)
#elif defined(JS_VERSION)
JSBool js_BB_Bridge_send(JSContext *cx, uint32_t argc, jsval *vp)
#endif
{
    if (1 != argc && 2 != argc) {
        JS_ReportError(cx, "Bridge.send expect 1 or 2 arguments");
        return false;
    }
    JS::CallArgs args = JS::CallArgsFromVp(argc, vp);
    auto arg = args.get(0);
    
    sdkbox::bb::Msg m(0);
    jsval2Msg(cx, arg, &m);

    if (2 == argc) {
        auto argf = args.get(1);
        auto f = new JS::PersistentRootedObject(cx, argf.toObjectOrNull());
        sdkbox::bb::Bridge::send(m, [cx, f](const sdkbox::bb::Msg& msg) {
            JS::RootedValue rMsg(cx);
            JS::RootedObject rObj(cx, f->get());

            sdkbox::bb::msg2JSVal(cx, msg, &rMsg);

            sdkbox::bb::invokeJSCallback(cx, rObj, rMsg);

             if (nullptr != f) { delete f; }
        });
    } else {
        sdkbox::bb::Bridge::send(m);
    }

    return true;
}

#if defined(MOZJS_MAJOR_VERSION)
#if MOZJS_MAJOR_VERSION >= 33
void register_Bridge_module(JSContext* cx, JS::HandleObject global) {
    JS::RootedObject pluginObj(cx);
    sdkbox::bb::getJsObjOrCreat(cx, global, "sdkbox.bb.Bridge", &pluginObj);

    JS_DefineFunction(cx, pluginObj, "onRecv",    js_BB_Bridge_onRecv,    1, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, pluginObj, "init",      js_BB_Bridge_init,      1, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, pluginObj, "addPlugin", js_BB_Bridge_addPlugin, 2, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, pluginObj, "send",      js_BB_Bridge_send,      2, JSPROP_READONLY | JSPROP_PERMANENT);
}
#else
void register_Bridge_module(JSContext* cx, JSObject* global) {
    JS::RootedObject pluginObj(cx);
    sdkbox::getJsObjOrCreat(cx, JS::RootedObject(cx, global), "sdkbox.bb.Bridge", &pluginObj);

    JS_DefineFunction(cx, pluginObj, "onRecv",    js_BB_Bridge_onRecv,    1, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, pluginObj, "init",      js_BB_Bridge_init,      1, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, pluginObj, "addPlugin", js_BB_Bridge_addPlugin, 2, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, pluginObj, "send",      js_BB_Bridge_send,      2, JSPROP_READONLY | JSPROP_PERMANENT);
}
#endif
#elif defined(JS_VERSION)
void register_Bridge_module(JSContext* cx, JSObject* global) {
    jsval pluginVal;
    JSObject* pluginObj;
    pluginVal = sdkbox::getJsObjOrCreat(cx, global, "sdkbox.bb.Bridge", &pluginObj);

    JS_DefineFunction(cx, pluginObj, "onRecv",    js_BB_Bridge_onRecv,    1, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, pluginObj, "init",      js_BB_Bridge_init,      1, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, pluginObj, "addPlugin", js_BB_Bridge_addPlugin, 2, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, pluginObj, "send",      js_BB_Bridge_send,      2, JSPROP_READONLY | JSPROP_PERMANENT);
}
#endif


