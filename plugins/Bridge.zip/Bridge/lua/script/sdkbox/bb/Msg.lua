local Msg = {}

local counter = 0

function Msg:create(pluginName, func)
    counter = counter + 1
    local m = {
        msgId = counter,
        plugin = pluginName,
        func = func,
        tag = "",
        values = {}
    }
    self.__index = self

    return setmetatable(m, self)
end

function Msg:setPlugin(s)
    self.plugin = s
end

function Msg:setFunc(s)
    self.func = s
end

function Msg:setTag(s)
    self.tag = s
end

function Msg:pushValue(v)
    self.values = self.values or {}
    self.values[#self.values+1] = v
end

function Msg:clearValues()
    self.values = {}
end

return Msg
