#pragma once

#import <Foundation/Foundation.h>

@interface BBAdUnitInfo : NSObject

@property (nonatomic, strong) NSString *adId;
@property (nonatomic, strong) NSString *adName;
@property (nonatomic, strong) NSString *adType;
@property (nonatomic, strong) NSString *alignment;
@property (nonatomic, assign) NSInteger width;
@property (nonatomic, assign) NSInteger height;

-(void)setDic: (NSDictionary*)dic;

@end

