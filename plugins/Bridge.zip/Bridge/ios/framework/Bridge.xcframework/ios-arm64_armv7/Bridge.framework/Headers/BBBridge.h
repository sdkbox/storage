#pragma once

#import <UIKit/UIKit.h>

@interface BBBridge : NSObject

// Open URI-scheme for iOS 9 and above
+ (BOOL)application:(UIApplication *_Nonnull)application
            openURL:(NSURL *)url
            options:(NSDictionary *) options;

// Open URI-scheme for iOS 8 and below
+ (BOOL)application: (UIApplication *)application
            openURL: (NSURL *)url
  sourceApplication: (NSString*)sourceApplication
         annotation: (id)annotation;

// Open Universal Links
+ (BOOL)application     : (UIApplication *)application
    continueUserActivity: (NSUserActivity *)userActivity
      restorationHandler: (void(^_Nullable)(NSArray<id<UIUserActivityRestoring>> * __nullable restorableObjects))restorationHandler;

// Report Push Notification attribution data for re-engagements
+ (void)application            : (UIApplication *_Nonnull)application
   didReceiveRemoteNotification: (NSDictionary *_Nullable)userInfo
         fetchCompletionHandler: (void (^_Nullable)(UIBackgroundFetchResult result))completionHandler;


// scene degelate
+ (void)scene    : (UIScene *_Nullable)scene
  openURLContexts: (NSSet<UIOpenURLContext *> *_Nullable)URLContexts API_AVAILABLE(ios(13.0));

+ (void)scene        : (UIScene *_Nullable)scene
 continueUserActivity: (NSUserActivity *_Nullable)userActivity API_AVAILABLE(ios(13.0));

@end
