#pragma once

#import <UIKit/UIKit.h>

@interface BBUtilsIOS : NSObject

+ (id)getIdFromDic: (NSDictionary*)dic key: (NSString*) k;
+ (NSString*)getStringFromDic: (NSDictionary*)dic key: (NSString*) k;
+ (NSInteger)getIntFromDic: (NSDictionary*)dic key: (NSString*) k;
+ (BOOL)getBoolFromDic: (NSDictionary*)dic key: (NSString*) k;

+ (UIViewController*)getRootViewController;

+ (NSString*)dic2json: (NSDictionary*)dic;
+ (NSDictionary*)json2dic: (NSString*)json;
+ (NSArray*)json2arr: (NSString*)json;

+ (BOOL)isEmpty: (NSString*)s;

+ (NSString*)reversalStr: (NSString*)str;

@end

