#pragma once

#import <Foundation/Foundation.h>

@interface BBMsg : NSObject

@property (nonatomic) NSInteger msgId;
@property (nonatomic, strong) NSString* plugin;
@property (nonatomic, strong) NSString* func;
@property (nonatomic, strong) NSString* tag;
@property (nonatomic, retain) NSMutableArray* values;

- (void)cleanValues;
- (void)pushValueNumber: (NSNumber*)n;
- (void)pushValueString: (NSString*)s;
- (void)pushValueData: (NSData*)bytes;

- (id)getValue:(NSInteger) idx;
- (NSString*)getValueString:(NSInteger) idx;
- (NSNumber*)getValueNumber:(NSInteger) idx;
- (BOOL)getValueBOOL:(NSInteger) idx;
- (NSArray*)getValueList:(NSInteger) idx;

- (NSMutableArray*)getValues;
- (NSInteger)getValuesLength;

@end

