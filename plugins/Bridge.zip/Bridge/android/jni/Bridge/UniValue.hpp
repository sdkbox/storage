#pragma once

#include <string>
#include <map>
#include <list>

namespace sdkbox {
namespace bb {

class UniValue;

typedef std::map<std::string, UniValue>   UniValueMap;
typedef UniValueMap::const_iterator       UniValueMapIterator;
typedef std::list<UniValue>               UniValueList;
typedef UniValueList::const_iterator      UniValueListIterator;

typedef enum {
    UniValueTypeNone,
    UniValueTypeInt,
    UniValueTypeFloat,
    UniValueTypeBoolean,
    UniValueTypeString,
    UniValueTypeByteArray,
    UniValueTypeMap,
    UniValueTypeList,
} UniValueType;

typedef struct {
    const unsigned char* pBytes;
    int l;
} UniValueBytes;

typedef union {
    int                 intValue;
    float               floatValue;
    bool                booleanValue;
    std::string*        stringValue;
    UniValueBytes       byteArrayValue;
    UniValueMap*        mapValue;
    UniValueList*       listValue;
} UniValueField;

class UniValue {

public:

    static const UniValue intValue(const int intValue);
    static const UniValue floatValue(const float floatValue);
    static const UniValue booleanValue(const bool booleanValue);
    static const UniValue stringValue(const std::string& stringValue);
    static const UniValue byteArrayValue(const unsigned char* byteArrayValue, int len);
    static const UniValue mapValue(const UniValueMap& mapValue);
    static const UniValue listValue(const UniValueList& listValue);

    UniValue(void)
    : _type(UniValueTypeNone) {
        memset(&_field, 0, sizeof(_field));
    }

    UniValue(const UniValue& rhs);
    UniValue& operator=(const UniValue& rhs);
    UniValue& operator=(const UniValue&& rhs);

    ~UniValue(void);

    UniValueType getType() const {
        return _type;
    }

    int intValue(void) const {
        return _field.intValue;
    }

    float floatValue(void) const {
        return _field.floatValue;
    }

    bool booleanValue(void) const {
        return _field.booleanValue;
    }

    const std::string& stringValue(void) const {
        if (UniValueType::UniValueTypeString != _type) return empty_string;
        return *_field.stringValue;
    }

    const unsigned char* byteArrayValue(int* pLen) const {
        *pLen = _field.byteArrayValue.l;
        return _field.byteArrayValue.pBytes;
    }

    const UniValueMap& mapValue(void) const {
        return *_field.mapValue;
    }

    const UniValueList& listValue(void) const {
        return *_field.listValue;
    }

private:

    UniValueField     _field;
    UniValueType      _type;

    void copy(const UniValue& rhs);
    
private:
    static const std::string empty_string;
};

}
}
