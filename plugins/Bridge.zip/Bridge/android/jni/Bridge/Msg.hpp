#pragma once

#include <string>
#include <vector>

#include "./UniValue.hpp"
#include "./Status.hpp"

namespace sdkbox {
namespace bb {

class Msg {

public:
    Msg(int msgId);
    Msg(const std::string& plugin, const std::string& func);
    Msg(const Msg&& msg);
    Msg(const Msg& msg);

    inline void setId(int i) { msgId = i; }
    inline int getId() const { return msgId; }

    inline void setPlugin(const std::string& p) { plugin = p; }
    inline const std::string& getPlugin() const { return plugin; }
    inline void setFunc(const std::string& f) { func = f; }
    inline const std::string& getFunc() const { return func; }
    inline void setTag(const std::string& t)  { tag = t; }
    inline const std::string& getTag() const { return tag; }

    void pushValue(int i);
    void pushValue(bool b);
    void pushValue(const std::string& s);
    void pushValue(unsigned char* bytes, int len);
    void pushValue(const UniValue& uniVal);

    void clearValues();
    const UniValue& getValue(int idx) const;
    const UniValueList& getValueList() const { return values; }
    const int getValueListLength() const { return (int)values.size(); }

private:
    int msgId;
    std::string plugin;
    std::string func;
    std::string tag;

    UniValueList values;
};

}
}
