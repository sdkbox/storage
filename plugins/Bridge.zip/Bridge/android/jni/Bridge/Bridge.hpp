#pragma once

#include <string>
#include <vector>
#include <map>
#include <functional>
#include "./Msg.hpp"

namespace sdkbox {
namespace bb {

class Bridge {
public:
    static void onRecv(const std::function<void(const Msg& msg)>& onResult = nullptr);
    static void init(const std::map<std::string, std::string>& plugins = std::map<std::string, std::string>());
    static void addPlugin(const std::string& name, const std::string& pluginClsName);
    static void send(Msg& msg, const std::function<void(const Msg& msg)>& onResult = nullptr);
};

}
}
