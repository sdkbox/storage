#pragma once

#define BB_STATUS_SUC                  0
#define BB_STATUS_ERR                  1

#define BB_STATUS_PLUGIN_NOT_EXIST     101
#define BB_STATUS_PLUGIN_INVOKE_FAIL   102

#define BB_STATUS_AD_LOAD_SUC          1001
#define BB_STATUS_AD_LOAD_FAIL         1002
#define BB_STATUS_AD_SHOW              1003
#define BB_STATUS_AD_CLOSE             1004
#define BB_STATUS_AD_SKIP              1005
#define BB_STATUS_AD_CLICK             1006
#define BB_STATUS_AD_REWARD            1007

// just for android
#define BB_STATUS_AD_APP_DOWNLOAD_IDLE    1101
#define BB_STATUS_AD_APP_DOWNLOAD_ING     1102
#define BB_STATUS_AD_APP_DOWNLOAD_PAUSE   1103
#define BB_STATUS_AD_APP_DOWNLOAD_FINISH  1104
#define BB_STATUS_AD_APP_DOWNLOAD_FAIL    1105
#define BB_STATUS_AD_APP_INSTALLED        1106



